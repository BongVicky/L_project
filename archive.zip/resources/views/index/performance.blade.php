<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Index Page</title>
    <link rel="stylesheet" href="{{asset('css/app.css')}}">
</head>
<body>
<div class="container">
    <br />
    @if (\Session::has('success'))
        <div class="alert alert-success">
            <p>{{ \Session::get('success') }}</p>
        </div><br />
    @endif
    <table class="table table-striped">
        <thead>
        <tr>
            <th>Employee ID</th>
            <th>Job Knowledge</th>
            <th>Work Quality</th>
            <th>Attendance</th>
            <th>Communication and Listening</th>
            <th>Dependability</th>

            <th colspan="2">Action</th>
        </tr>
        </thead>
        <tbody>

        @foreach($employees as $employee)
            @php
                $date=date('Y-m-d', $employee['date']);
            @endphp
            <tr>
                <td>{{$employee['id']}}</td>
                <td>{{$employee['job_knowledge']}}</td>
                <td>{{$employee['work_quality']}}</td>
                <td>{{$employee['attendance']}}</td>
                <td>{{$employee['com_listen']}}</td>
                <td>{{$employee['dependability']}}</td>

                <td><a href="{{action('EmployeesController@edit', $employee['id'])}}" class="btn btn-warning">Edit</a></td>
                <td>
                    <form action="{{action('EmployeesController@destroy', $employee['id'])}}" method="post">
                        @csrf
                        <input name="_method" type="hidden" value="DELETE">
                        <button class="btn btn-danger" type="submit">Delete</button>
                    </form>
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>
</div>
</body>
</html>