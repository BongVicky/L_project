@extends('main')

@section('title', ' Employees List')
@section('content')

    {{--To view all employees info--}}

    <div class="col-md-9" style="font-size: 10px">
        @if (\Session::has('success'))
            <div class="alert alert-success">
                <p>{{ \Session::get('success') }}</p>
            </div><br />
        @endif
        <div class="card">
            <div class="card-body">
                <h5>Employees List</h5>
                {{--{{action('employees.createEmp')}}--}}
                <table class="table">

                            <a href="{{action('EmployeeController@create')}}" >
                                <button class="btn btn-primary" type="submit" style="margin-bottom: 10px">
                                    Add New
                                </button>
                            </a>



                    <thead class="thead-dark">
                    <tr>
                        <th scope="">ID</th>
                        <th scope="">Name</th>
                        <th scope="">Gender</th>
                        <th scope="">Email</th>
                        <th scope="">Position</th>
                        <th scope="">Action</th>
                    </tr>
                    </thead>
                    <tbody>

                    @foreach($employees as $employee)
                        @php
                            $date=date('Y-m-d', $employee['date']);
                        @endphp

                        <tr class="">
                            <td>{{$employee['id']}}</td>
                            <td>{{$employee['name']}}</td>
                        @if ($employee->gender == 1)
                                <td>Male</td>
                        @else
                                <td>Female</td>
                                @endif
                            {{--<td>{{$employee['gender']}}</td>--}}
                            <td>{{$employee['email']}}</td>
                            <td>{{$employee['position']}}</td>
                            <td>

                                <a href="{{action('EmployeeController@show', $employee['id'])}}">
                                    <button class="btn btn-primary" type="submit">
                                        <i class="fa fa-eye" aria-hidden="true"></i>
                                    </button>
                                </a>
{{--                                href="{{action('PassportController@edit', $employee['id'])}}"--}}
                                <a href="{{action('EmployeeController@edit', $employee['id'])}}">
                                    <button class="btn btn-primary" type="submit">
                                        <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                                    </button>
                                </a>
                                <form class="crud" action="{{action('EmployeeController@destroy', $employee['id'])}}" method="post">
                                    {{--@csrf--}}
                                    {{--<input name="_method" type="hidden" value="DELETE">--}}
                                    {{--<button class="btn btn-danger" type="submit">--}}
                                        {{--<i class="fa fa-trash-o" aria-hidden="true"></i>--}}
                                    {{--</button>--}}
                                    {{----}}
                                    <!-- Button trigger modal -->
                                        @csrf
                                        <button onclick="return confirm('Are you sure you want to delete this item?');" type="submit" class="btn btn-danger" data-toggle="modal" data-target="#exampleModalCenter">
                                            <i class="fa fa-trash-o" aria-hidden="true"></i>
                                        </button>
                                        <input name="_method" type="hidden" value="DELETE">
                                  </form>

                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>

            <p></p>
        </div>
    </div>

@endsection