@extends('main')

@section('title', ' Employee Information')

@section('content')

    <div class="col-md-9">


        <div class="card">
            <div class="card-body">

                <h5>{{$employee->name}}</h5>
                <h6>Employee ID: {{$employee->id}}</h6>
                <p><b>Total Annual Leave : </b>18 days</p>
                <hr>

                <p><b>Date of Birth : </b>{{$employee->dob}}</p>
                <p><b>Gender : </b> @if ($employee->gender == 1)
                        Male
                     @else
                        Female
                     @endif
                </p>
                <p><b>Email : </b>{{$employee->email}}</p>
                <hr>
                <h5>Leave History</h5>

                <table class="table">
                    <thead class="thead-dark">
                    <tr>
                        <th scope="">#</th>
                        <th scope="">Name</th>
                        <th scope="">Leave Type</th>
                        <th scope="">Date</th>
                        <th scope="">Reason</th>

                    </tr>
                    </thead>
                    <tbody>
                    <tr class="">
                        <th scope="row">
                            {{$employee->id}}
                        </th>
                        <td>{{$employee->name}}</td>
                        <td>Casual Leave</td>
                        <td>24 July, 2018 to 26 July, 2018</td>
                        <td>Going to Family Function</td>

                    </tr>



                    </tbody>

                </table>
                <div class="col-md-12 text-right">
                    <a href="{{action('EmployeeController@index')}}">
                        <button class="btn btn-primary text-right" type="submit">
                            Back
                        </button>
                    </a>
                </div>

            </div>
        </div>

    </div>

@endsection