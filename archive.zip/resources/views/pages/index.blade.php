@extends('main')

@section('title', ' Leave Request')
@section('content')

        {{--To view employees info and their annual leave--}}

        <div class="col-md-9" style="font-size: 10px">
            @if (\Session::has('success'))
                <div class="alert alert-success">
                    <p>{{ \Session::get('success') }}</p>
                </div><br />
            @endif
            <div class="card">
                <div class="card-body">
                   <h5>Leaving Request</h5>

                    <table class="table">
                        <thead class="thead-dark">
                        <tr>
                            <th scope="">ID</th>
                            <th scope="">Name</th>
                            <th scope="">Leave Date</th>
                            <th scope="">Return Date</th>
                            <th scope="">Number of Day(s)</th>
                            <th scope="">Leave Type</th>
                            <th scope="">Reason</th>
                            <th scope="">Action</th>
                        </tr>
                        </thead>
                        <tbody>

                        @foreach($attendances as $attendance)
                            @php
                                $date=date('Y-m-d', $attendance['date']);
                            @endphp
                        <tr class="">
                            <td>{{$attendance['id']}}</td>
                            <td>{{$attendance['name']}}</td>
                            <td>{{$attendance['leave_date']}}</td>
                            <td>{{$attendance['return_date']}}</td>
                            <td>{{$attendance['numberofday']}}</td>
                            <td>{{$attendance['leave_type']}}</td>
                            <td>{{$attendance['reason']}}</td>
                            <td>

                                <a href="{{action('AttendanceController@edit', $attendance['id'])}}">
                                    <button class="btn btn-primary" type="submit">
                                        <i class="fa fa-pencil-square" aria-hidden="true"></i>
                                    </button>
                                </a>


                                {{--<form method="post" action="{{action('AttendanceController@destroy', $attendance['id'])}}" class="crud">--}}
                                <form class="crud" action="{{action('AttendanceController@destroy', $attendance['id'])}}" method="post">
                                {{--@csrf--}}
                                {{--<input name="_method" type="hidden" value="DELETE">--}}
                                {{--<button class="btn btn-danger" type="submit">--}}
                                {{--<i class="fa fa-trash-o" aria-hidden="true"></i>--}}
                                {{--</button>--}}
                                {{----}}
                                <!-- Button trigger modal -->
                                    @csrf
                                    <button onclick="return confirm('Are you sure you want to delete this item?');" type="submit" class="btn btn-danger" data-toggle="modal" data-target="#exampleModalCenter">
                                        <i class="fa fa-trash-o" aria-hidden="true"></i>
                                    </button>
                                    <input name="_method" type="hidden" value="DELETE">
                                </form>

                            </td>
                        </tr>
                        @endforeach
                        </tbody>

                    </table>
                </div>

                <p></p>
            </div>
        </div>

@endsection