@extends('main')

@section('title', ' Employee Info')

@section('content')

    <div class="col-md-9">

        <h4>Edit Employee</h4>
        <br>
        <div class="card">
            <div class="card-body">
                <form method="post" action="/employees/{{$id}}" enctype="multipart/form-data">

                    <input name="_method" type="hidden" value="PATCH">
                    @csrf
                    <div class="form-group" >
                        <label style="padding-right: 10px" class="form-inline" for="Name">Name : </label>
                        <input type="text" class="form-control" placeholder="Name" name="name" value="{{$employee->name}}" required>

                    </div>
                    <div class="form-group" >
                        <label style="padding-right: 10px" class="form-inline" for="Email">Email : </label>
                        <input type="email" class="form-control" placeholder="Email" name="email" value="{{$employee->email}}" required>

                    </div>
                    <div class="form-group form-inline">
                        <label style="padding-right: 10px" for="Position">Position: </label>
                        <input style="margin-right: 10px" type="text" class="form-control" value="{{$employee->position}}" placeholder="Position" name="position" required>

                        <label style="padding-right: 10px" for="Leave_type">Gender: </label>
                        <select class="form-control" name="gender" value="{{$employee->gender}}" required>
                            <option value="1" @if($employee->gender == "1") selected @endif >Male</option>
                            <option value="0" @if($employee->gender == "0") selected @endif >Female</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label style="padding-right: 10px" class="form-inline" for="dob">Date of Birth : </label>
                        <input type="text" class="form-control date datepicker" name="dob" value="{{$employee->dob}}" required>
                    </div>

                    <div class="form-group">
                        <label style="padding-right: 10px" class="form-inline" for="hire_date">Hire Date : </label>
                        <input type="text" class="form-control date datepicker" name="hire_date" value="{{$employee->hire_date}}" required>
                    </div>
                    <div class="form-group ">
                        <label style="padding-right: 10px" class="form-inline" for="hire_date">Monthly Leave : </label>
                        <input style="margin-right: 10px" type="text" class="form-control" placeholder="" value="{{$employee->monthly_leave}}" name="monthly_leave" required>
                    </div>

                    <div class="text-right">

                        <button type="submit" class="btn btn-primary">Update</button>

                        <button class="btn btn-secondary">Cancel</button>


                    </div>


                </form>

            </div>
        </div>

    </div>


@endsection