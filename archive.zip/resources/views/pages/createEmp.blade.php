@extends('main')

@section('title', ' Employee Information')

@section('content')

    <div class="col-md-9">

        <h4>New Employee</h4>
        <br>
        <div class="card">
            <div class="card-body">

                <form method="post" action="{{url('employees')}}" enctype="multipart/form-data">
                    @csrf
                    <div class="form-group" >
                        <label style="padding-right: 10px" class="form-inline" for="Name">Name : </label>
                        <input type="text" class="form-control" placeholder="Name" name="name" required>

                    </div>
                    <div class="form-group" >
                        <label style="padding-right: 10px" class="form-inline" for="Email">Email : </label>
                        <input type="email" class="form-control" placeholder="Email" name="email" required>

                    </div>
                    <div class="form-group form-inline">
                        <label style="padding-right: 10px" for="Position">Position: </label>
                        <input style="margin-right: 10px" type="text" class="form-control" placeholder="Position" name="position" required>

                        <label style="padding-right: 10px" for="Leave_type">Gender: </label>
                        <select class="form-control" name="gender" required>
                            <option value="1">Male</option>
                            <option value="0">Female</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label style="padding-right: 10px" class="form-inline" for="dob">Date of Birth : </label>
                        <input type="text" class="form-control date datepicker" name="dob" required>
                    </div>
                    {{--<div class="row">--}}
                    {{--<div class="col-md-4"></div>--}}
                    {{--<div class="form-group col-md-4">--}}
                    {{--<strong>Date : </strong>--}}
                    {{--<input class="date form-control"  type="text" id="datepicker" name="date">--}}
                    {{--</div>--}}
                    {{--</div>--}}

                    <div class="form-group">
                        <label style="padding-right: 10px" class="form-inline" for="hire_date">Hire Date : </label>
                        <input type="text" class="form-control date datepicker" name="hire_date" required>
                    </div>
                    <div class="form-group ">
                        <label style="padding-right: 10px" class="form-inline" for="hire_date">Monthly Leave : </label>
                        <input style="margin-right: 10px" type="text" class="form-control" placeholder="" name="monthly_leave" required>
                    </div>

                    <div class="text-right">

                        <button type="submit" class="btn btn-primary">Submit</button>

                        <button class="btn btn-secondary">Cancel</button>


                    </div>

                </form>

            </div>
        </div>

    </div>


@endsection