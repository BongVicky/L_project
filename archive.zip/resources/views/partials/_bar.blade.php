{{--LeftBar--}}
<div class="col-md-3">
    <div class="row">
        <div class="col-md-4">
            <img src="{{asset('img/xs/avatar1.png')}}" width="100%">
        </div>
        <div class="col-md-8 dropdown">
            <span>Welcome,</span>
            <div class="btn-group">
                <button class="btn btn-sm dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Jonny Depp
                </button>
                <div class="dropdown-menu">
                    <a class="dropdown-item warning" href="#"><i class="fa fa-info-circle" aria-hidden="true"></i>&nbsp;Lorem ipsum dolor sit ame.</a>
                    <a class="dropdown-item" href="#"><i class="fa fa-thumbs-o-up" aria-hidden="true"></i>&nbsp;On the other hand.</a>
                    <a class="dropdown-item" href="#"><i class="fa fa-pie-chart" aria-hidden="true"></i>&nbsp;I am awesome</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="#"><i class="fa fa-power-off" aria-hidden="true"></i>&nbsp;Je suis parfait.</a>
                </div>
            </div>
        </div>
    </div>

    <hr>
    <ul class="nav nav-tabs" id="myTab" role="tablist">
        <li class="nav-item">
            <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">HR</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Project</a>
        </li>
    </ul>
    <div class="tab-content" id="myTabContent">
        <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
            <br>
                        <a href="/home">
                        <button type="button" class="btn btn-outline-primary btn-sm btn-block text-left " width="100%">

                            <i class="fa fa-tachometer icon-space" aria-hidden="true"></i>HR Dashboard

                        </button>
                        </a>
            <a href="/holiday">
            <button type="button" class="btn btn-outline-primary btn-sm btn-block text-left">
                <i class="fa fa-list icon-space" aria-hidden="true"></i>Holiday
            </button>
            </a>
            <a href="/calendar">
            <button type="button" class="btn btn-outline-primary btn-sm btn-block text-left">
                <i class="fa fa-calendar icon-space" aria-hidden="true"></i>Calendar
            </button>
            </a>
            <a href="/employees">
            <button type="button" class="btn btn-outline-primary btn-sm btn-block text-left">
                <i class="fa fa-users icon-space" aria-hidden="true"></i>Employees
            </button>
            </a>
            <a href="/leaveRequest">
            <button type="button" class="btn btn-outline-primary btn-sm btn-block text-left">
                <i class="fa fa-suitcase icon-space" aria-hidden="true"></i>Leave Request
            </button>
            </a>
            <a href="/">
            <button type="button" class="btn btn-outline-primary btn-sm btn-block text-left">
                <i class="fa fa-bar-chart icon-space" aria-hidden="true"></i>Report
            </button>
            </a>
            <a href="/">
            <button type="button" class="btn btn-outline-primary btn-sm btn-block text-left">
                <i class="fa fa-user icon-space" aria-hidden="true"></i>Users
            </button>
            </a>
            <a href="/">
            <button type="button" class="btn btn-outline-primary btn-sm btn-block text-left">
                <i class="fa fa-lock icon-space" aria-hidden="true"></i>Authentication
            </button>
            </a>
        </div>
        <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
            <br>
            <button type="button" class="btn btn-outline-primary btn-sm btn-block text-left">
                <i class="fa fa-tachometer icon-space" aria-hidden="true"></i>Dashboard
            </button>
            <button type="button" class="btn btn-outline-primary btn-sm btn-block text-left">
                <i class="fa fa-envelope-o icon-space" aria-hidden="true"></i>Inbox
            </button>
            <button type="button" class="btn btn-outline-primary btn-sm btn-block text-left">
                <i class="fa fa-comments-o icon-space" aria-hidden="true"></i>Chat
            </button>
            <button type="button" class="btn btn-outline-primary btn-sm btn-block text-left">
                <i class="fa fa-list icon-space" aria-hidden="true"></i>Projects
            </button>
            <button type="button" class="btn btn-outline-primary btn-sm btn-block text-left">
                <i class="fa fa-users icon-space" aria-hidden="true"></i>Clients
            </button>
            <button type="button" class="btn btn-outline-primary btn-sm btn-block text-left">
                <i class="fa fa-tags icon-space" aria-hidden="true"></i>Taskboard
            </button>

        </div>
    </div>

</div>
{{--End LeftBar--}}