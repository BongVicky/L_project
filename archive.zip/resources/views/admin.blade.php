@extends('layouts.app')

@section('content')
    <h1><Strong>Admin</Strong></h1>
@endsection