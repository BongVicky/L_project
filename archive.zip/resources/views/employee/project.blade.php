<div class="row" style="margin-top: 40px; margin-bottom: 30px;">
    <div class="col-md-10 col-sm-10 col-md-offset-1 col-sm-offset-1">
        <h1><strong> Current Project </strong></h1>
        <hr>
        <div class="row">
            <div class="col-md-12">
                <div class="jumbotron">
                    <h2><strong>Project: </strong>Welcome to my blog!!</h2>
                    <p><strong>Description: </strong> Thank you for visiting. This is my testing laravel project.</p>
                    <p>
                    <hr>
                    <a class="btn btn-primary btn-lg" href="#" role="button">More Detail</a></p>
                </div>
            </div>
        </div>
        <hr>
        <div class="row">
            <blockquote style="margin-top: 20px">
                <div class="col-sm-offset-1 col-md-offset-1 col-md-10 col-sm-10">
                    <div class="post">
                        <h2><strong>Post Title</strong></h2>
                        <p>
                            Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                            Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
                            when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                        </p>
                        <p><a href="#" class="btn btn-primary btn-lg" role="button"> More </a></p>
                    </div>
                    <hr>
                    <div class="post">
                        <h2><strong>Post Title</strong></h2>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                            Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
                            when an unknown printer took a galley of type and scrambled it to make a type specimen
                            book.</p>
                        <p><a href="#" class="btn btn-primary btn-lg" role="button"> More </a></p>
                    </div>
                    <hr>
                    <div class="post">
                        <h2><strong>Post Title</strong></h2>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                            Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
                            when an unknown printer took a galley of type and scrambled it to make a type specimen
                            book.</p>
                        <p><a href="#" class="btn btn-primary btn-lg" role="button"> More </a></p>

                    </div>
            </blockquote>
        </div>
    </div>
</div>