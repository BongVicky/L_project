<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class performances extends Model
{
    //
}
