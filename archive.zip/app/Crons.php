<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Crons extends Model
{
    //
}
